<?php
$manifest = array (
  'id' => 'SugarDevelopersGuideAccountsRestApiExample',
  'name' => 'Accounts RestAPI Example',
  'description' => 'Installable examples for Sugar customizations.',
  'version' => '1.0.1',
  'author' => 'Sugar Developers Guide',
  'is_uninstallable' => true,
  'built_in_version' => '26.1.0',
  'published_date' => '2026-10-29 17:13:37',
  'type' => 'module',
  'remove_tables' => false,
  'acceptable_sugar_versions' => 
  array (
    'regex_matches' => 
    array (
      0 => '^26\\.(.*?)\\.(.*?)',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'PRO',
    1 => 'ENT',
    2 => 'ULT',
  ),
);
$installdefs = array (
  'id' => 'SugarDevelopersGuideAccountsRestApiExample',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/application/Ext/Platforms/sdg_examples.php',
      'to' => 'custom/Extension/application/Ext/Platforms/sdg_examples.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/custom/modules/Accounts/clients/base/api/SdgAccountSummaryApi.php',
      'to' => 'custom/modules/Accounts/clients/base/api/SdgAccountSummaryApi.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/custom/modules/Accounts/Services/AccountReadinessService.php',
      'to' => 'custom/modules/Accounts/Services/AccountReadinessService.php',
    ),
  ),
);
